USBPrintingNG - The Next-Gen version of the 3DPrinting Plugin bundled with Cura
    - Skips baud-rate auto-detection if system environment variable CURA_BAUDRATES is set.
    - When both CURA_BAUDRATES and CURA_DEVICENAMES are set makes direct connection to the printer unless overridden by CURA_AUTODETECT set to 1
    - Changes Print to USB text for printer if CURA_DEVICE_NAMES is defined.

- Installation Recommendations
    - We currently assume you are using one printer in the instance of cura you are using this with. To use this with multiple printers in the same version of cura use a batch file to set the environment variables and then launch cura from there so it can read them in.
    - We highly recommend you disable the bundled/built-in "USB Printing" plugin/package while using this so they do not fight for control over your printers.

- Environment Variables
    - CURA_AUTODETECT [0|1]
        - When set to 0 will force autodetection off. Must have CURA_BAUDRATE and CURA_COMPORTS set.
        - When set to 1 will force autodetection on. This is the default behavior.
    - CURA_BAUDRATE [nnnnnn]
        - Used when Autodetection is disabled. Currently only a single baud rate is supported.
    - CURA_BAUDRATES [nnnnn,nnnnnn,nnnnn]
        - Used by autodetection to override the default baud list.
    - CURA_COMPORTS [COMn,COMn,COMn]
        - Used to only look at specific com ports
    - CURA_DEVICE_NAMES [name 1]
        - When defined sets "Print to USB" text to "Print to USB <name 1>" instead of "Print to USB NG".
    
- The following are changes and improvements over the bundled version of the USBPrinting Plugin.
    - Now parses full M115 string for logical use elsewhere.
        - Firmware Full Name: FIRMWARE_NAME (ignores ; like built-in firmware name does)
        - Firmware URL: SOURCE_CODE_URL or FIRMWARE_URL
        - Firmware Protocol: PROTOCOL_VERSION
        - Firmware Machine Type: MACHINE_TYPE
        - Firmware Extruder Count: EXTRUDER_COUNT
        - Firmware UUID: UUID
    - When Autodetect is disabled printer connection is almost instant.
    - Increased bootloader timeout on detection from 1.5 seconds to 3 seconds. This reduces possible misses on first try.
    - Better Logging for printer detection in cura.log.

- Bug Fixes

- UI Changes
    - Print text change from "Print to USB" to "Print to USB NG" to provide a distinction between the bundled plugin and ours during uses.

- Known Issues, Limitations & Future Changes
    - Currently only supports one printer configuration by use of environment variables. Future version will support CSV list of baud rates in CURA_BAUDRATE and CURA_COMPORTS. Environment Variables may be entered in pairs such as 'COM3,COM4' and '115200,250000'. This skips autodetection (with CURA_AUTODETECT undefined or set to 0) and would make a direct connections to COM3 at 115200 and COM4 at 250000."
    - [cura bug] autodetect may incorrectly think it's succesfully negotiated a higher speed because it has as serial connection already when it tries the next baud rate in the list. This causes the printer to not work right at all and must be reset to find it again.

- Useful URLS
https://pyserial.readthedocs.io/en/latest/shortintro.html
https://pyserial.readthedocs.io/en/latest/pyserial_api.html
https://sourceforge.net/p/pyserial/code/HEAD/tree/tags/release2_7/documentation/
